import 'package:flutter/material.dart';
import 'package:kuis_application/models/news.dart';
import 'package:kuis_application/services/api_services.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  final ApiService _apiService = ApiService();

  List<News> _allNews = [];


  @override
  void initState() {
    super.initState();
    _loadNews();
  }

  Future<void> _loadNews() async {
    final List<Map<String, dynamic>> allNewsData =
        await _apiService.getAllNews();


    setState(() {
      _allNews = allNewsData.map((e) => News.fromJson(e)).toList();

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Berita Yusuf'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildNewsList('Berita Terbaru', _allNews),

          ],
        ),
      ),
    );
  }

  Widget _buildNewsList(String title, List<News> Berita) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          title,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      SizedBox(
        height: 200,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: Berita.length,
          itemBuilder: (context, index) {
            final News news = Berita [index]; // Fix is here
            return GestureDetector(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Text(
                      news.title.length > 14
                            ? '${news.title.substring(0, 10)}...'
                            : news.title,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                      news.author.length > 8
                            ? '${news.author.substring(0, 10)}...'
                            : news.author,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        news.publishedAt.length > 14
                            ? '${news.publishedAt.substring(0, 10)}...'
                            : news.publishedAt,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        )
      ],
    );
  }
}