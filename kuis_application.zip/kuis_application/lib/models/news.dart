class News {
  final int id;
  final String name;
  final String author;
  final String title;
  final String publishedAt;

  News({required this.id,
          required this.name,
          required this.author,
          required this.title,
          required this.publishedAt});
          factory News.fromJson(Map<String, dynamic> json) {
  return  News (
    id: json['id'] ?? 0, // Tambahkan `as int` untuk memastikan bahwa nilai yang diambil dari JSON adalah integer
    name: json['name'] ?? '',
    author: json['title'] ?? '', // Tambahkan `as String` untuk memastikan bahwa nilai yang diambil dari JSON adalah string
    title: json['author'] ?? '',
    publishedAt: json['title'] ?? '' ,// Ubah 'release_Date' menjadi 'release_date', pastikan nama properti sesuai dengan yang ada dalam JSON
  );
}
}