package com.example.utsyusufrahmana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
